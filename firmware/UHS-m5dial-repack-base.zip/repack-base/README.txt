Ultimate Homebrewing Scale M5Dial repack base.

This archive contains native UIFlow/M5Dial build artifacts and repack tools.
It is intended for GitHub Actions repack jobs, not direct flashing.

Expected final firmware asset name: UHS-firmwareM5Dial.bin
Board type: dial
Chip family: ESP32-S3
Source: origin/main 9195640 plus local memory fixes

Custom MBEDTLS settings:
CONFIG_MBEDTLS_DYNAMIC_BUFFER=y
CONFIG_MBEDTLS_DYNAMIC_FREE_CONFIG_DATA=y
CONFIG_MBEDTLS_DYNAMIC_FREE_CA_CERT=y
CONFIG_MBEDTLS_ASYMMETRIC_CONTENT_LEN=y
CONFIG_MBEDTLS_SSL_IN_CONTENT_LEN=16384
CONFIG_MBEDTLS_SSL_OUT_CONTENT_LEN=2048
CONFIG_MBEDTLS_SSL_KEEP_PEER_CERTIFICATE=n
