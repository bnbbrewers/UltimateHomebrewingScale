Ultimate Homebrewing Scale M5Dial repack base.

This archive contains native UIFlow/M5Dial build artifacts and repack tools.
It is intended for GitHub Actions repack jobs, not direct flashing.

Expected final firmware asset name: UHS-firmwareM5Dial.bin
Board type: dial
Chip family: ESP32-S3
